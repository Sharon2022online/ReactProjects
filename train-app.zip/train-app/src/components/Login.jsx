import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'

const Login = () => {
    const navigate=useNavigate()

    const [inputField,changeInputField]=useState(
        {
            "email":"",
            "password":""
        }
    )
    const inputHandler=(event)=>{
        changeInputField(
            {...inputField,[event.target.name]:event.target.value}
        )
    }
    const readValue=()=>{
        console.log(inputField)
        if (inputField.email=="admin@gmail.com" && inputField.password=="12345") {
            navigate("/add")
        }else{
            alert("Invalid Credentials")
        }
    }
    return (
        <div className="container">
            <div className="row justify-content-center">
                <div className="col-md-6">
                    <div className="border p-4"> {/* Added border and padding */}
                        <h1 className="text-center">Login</h1>
                        <form>
                            <div className="mb-3">
                                <label htmlFor="exampleFormControlInput1" className="form-label">Email address</label>
                                <input type="email" className="form-control" id="exampleFormControlInput1" placeholder="name@example.com" name='email' value={inputField.email} onChange={inputHandler} />
                            </div>
                            <div className="mb-3">
                                <label htmlFor="exampleInputPassword1" className="form-label">Password</label>
                                <input type="password" className="form-control" id="exampleInputPassword1" name='password' value={inputField.password} onChange={inputHandler}/>
                            </div>
                            <div className="d-grid gap-2">
                                <button onClick={readValue}className="btn btn-success" type="submit">LOGIN</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default Login