import React, { useState } from 'react'
import Nav from './Nav'
import axios from 'axios'

const Add = () => {
    const [inputField, changeInputField] = useState(
        {

            "train_no": "",
            "name": "",
            "departure": "",
            "destination": "",
            "duration": "",
            "types": ""

        }
    )
    const inputHandler = (x) => {
        changeInputField({ ...inputField, [x.target.name]: x.target.value })
    }
    const readValue = () => {
        console.log(inputField)
        axios.post("http://127.0.0.1:8000/api/add/",inputField).then(
            (response)=>{
                alert(response.data.status)
            }
        )
    }
  return (
    <div>
        <Nav/>
        <div className="container">
            <div className="row">
                <div className="col col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12 col-xxl-12">
                    <div className="row g-3">
                        <div className="col col-12 col-sm-6 col-md-6 col-lg-6 col xl-6 col xxl-6">
                            <label htmlFor="" className="form-label">Train No</label>
                            <input type="text" className="form-control" name='train_no' value={inputField.train_no} onChange={inputHandler} />
                        </div>
                        <div className="col col-12 col-sm-6 col-md-6 col-lg-6 col xl-6 col xxl-6">
                            <label htmlFor="" className="form-label">Name</label>
                            <input type="text" className="form-control" name='name' value={inputField.name} onChange={inputHandler} />
                        </div>
                        <div className="col col-12 col-sm-6 col-md-6 col-lg-6 col xl-6 col xxl-6">
                        <label htmlFor="" className="form-label">Departure</label>
                            <input type="text" className="form-control" name='departure' value={inputField.departure} onChange={inputHandler} />
                        </div>
                        <div className="col col-12 col-sm-6 col-md-6 col-lg-6 col xl-6 col xxl-6">
                        <label htmlFor="" className="form-label">Destination</label>
                            <input type="text" className="form-control" name='destination' value={inputField.destination} onChange={inputHandler}/>
                        </div>
                        <div className="col col-12 col-sm-6 col-md-6 col-lg-6 col xl-6 col xxl-6">
                        <label htmlFor="" className="form-label">Duration</label>
                            <input type="text" className="form-control" name='duration' value={inputField.duration} onChange={inputHandler}/>
                        </div>
                        <div className="col col-12 col-sm-6 col-md-6 col-lg-6 col xl-6 col xxl-6">
                        <label htmlFor="" className="form-label">Type</label>
                            <input type="text" className="form-control" name='types' value={inputField.types} onChange={inputHandler}/>
                        </div>
                        <div className="col col-12 col-sm-12 col-md-12 col-lg-12 col xl-12 col xxl-12">
                        <button className="btn btn-info" onClick={readValue}>ADD</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
  )
}

export default Add